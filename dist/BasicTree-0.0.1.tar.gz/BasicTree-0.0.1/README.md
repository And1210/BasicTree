# BasicTree

A basic tree library used to test out different searchs (such as depth-first or breadth-first).

